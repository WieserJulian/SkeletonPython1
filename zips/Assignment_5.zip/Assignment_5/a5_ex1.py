def sub_summarize(nested: list, sub_sums: list) -> int:
    # Todo Your code Here
    pass