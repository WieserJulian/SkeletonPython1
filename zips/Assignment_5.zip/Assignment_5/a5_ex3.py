def gen_fibonacci(upper_bound):
    # Todo Your code Here
    pass
