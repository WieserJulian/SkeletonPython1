import os.path

def print_directory(dir_path: str):
    # Todo Your code Here
    pass


def print_directory_recursively(dir_path: str, level: int):
    # Todo Your code Here
    pass
