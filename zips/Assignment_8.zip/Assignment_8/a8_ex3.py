class StandardScaler:

    def __init__(self):
        pass

    def fit(self, features: list):
        pass

    def transform(self, features: list):
        pass

    def fit_transform(self, features: list):
        pass

    def __getitem__(self, key):
        pass
