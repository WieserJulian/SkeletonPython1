class Power:

    def __init__(self, exponent):
        pass

    def __call__(self, x):
        pass

    def __mul__(self, other):
        pass


class Square(Power):

    def __init__(self):
        pass
