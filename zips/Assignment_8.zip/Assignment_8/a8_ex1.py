import math


class Angle:

    def __init__(self, degree: float = None, radian: float = None):
        pass

    def consistency(self):
        pass

    def __eq__(self, other):
        pass

    def __str__(self):
        pass

    def __repr__(self):
        pass

    def __iadd__(self, other):
        pass

    def __add__(self, other):
        pass

    @staticmethod
    def deg_to_rad(degree):
        pass

    @staticmethod
    def rad_to_deg(radian):
        pass

    @staticmethod
    def add_all(angle, *angles):
        pass
