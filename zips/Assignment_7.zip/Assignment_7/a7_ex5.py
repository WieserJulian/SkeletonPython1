from a7_ex3 import Distance


class Manhattan(Distance):
    def __init__(self, x: int, vect1: list, vect2: list):
        pass

    def to_string(self) -> str:
        pass

    def dist(self) -> float:
        pass
