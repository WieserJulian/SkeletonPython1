from a7_ex4 import Minkowski


class Euclidean(Minkowski):
    def __init__(self, x: int, vect1: list, vect2: list):
        pass

    def to_string(self) -> str:
        pass

    def dist(self) -> float:
        pass
