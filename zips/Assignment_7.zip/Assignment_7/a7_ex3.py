class Distance:
    def __init__(self, x):
        pass

    def to_string(self) -> str:
        pass

    def dist(self) -> float:
        pass
