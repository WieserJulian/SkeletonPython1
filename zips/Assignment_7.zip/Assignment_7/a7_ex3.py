class Distance:
    def __init__(self, x):
        self.x = x

    def to_string(self) -> str:
        pass

    def dist(self) -> float:
        pass
