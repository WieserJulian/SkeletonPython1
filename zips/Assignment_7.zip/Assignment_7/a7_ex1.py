class Radian:
    def __init__(self, degree: float):
        pass

    def rad(self) -> float:
        pass

    def print(self):
        pass
