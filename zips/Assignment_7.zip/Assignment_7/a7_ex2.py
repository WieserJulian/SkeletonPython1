from a7_ex1 import Radian


class Rotate(Radian):
    def __init__(self, matrix: list, degree: float, inplace=False):
        pass

    def rotation(self) -> list:
        pass
