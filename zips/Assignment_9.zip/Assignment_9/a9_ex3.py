import argparse
import math
from functools import partial
from multiprocessing import Pool


def sum_of_fractions(start: int, end: int) -> float:
    pass


if __name__ == '__main__':
    pass
