import re


def extract_emails(text: str) -> list[str]:
    pass
