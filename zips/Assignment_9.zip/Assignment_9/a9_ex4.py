import argparse
import math
import subprocess
from functools import partial
from multiprocessing import Pool

if __name__ == '__main__':
    pass
