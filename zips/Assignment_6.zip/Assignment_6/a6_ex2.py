import os.path


def chunks(path: str, size: int, **kwargs):
    # Todo Your code Here
    pass
