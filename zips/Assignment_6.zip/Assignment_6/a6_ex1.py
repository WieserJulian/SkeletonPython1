import os.path


def file_statistics(path: str):
    # Todo Your code Here
    pass
