def merge_csv_files(*paths: str, delimiter=';', only_shared_columns=False):
    # Todo Your code Here
    pass