import os
import datetime
import pickle


def create_user(name: str, data: str, password: str, log_file: str = "logs.txt"):
    # Todo Your code Here
    pass


def login(name: str, password: str, log_file: str = 'logs.txt'):
    # Todo Your code Here
    pass


def change_password(name: str, old_password: str, new_password: str, log_file: str = 'logs.txt'):
    # Todo Your code Here
    pass
