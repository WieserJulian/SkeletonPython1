import numpy as np


def moving_average_2D(arr: np.ndarray, size: int) -> np.ndarray:
    pass


