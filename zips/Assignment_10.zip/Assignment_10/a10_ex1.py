import numpy as np


def extend(arr: np.ndarray, rows: int, cols: int, fill=None) -> np.ndarray:
    pass
