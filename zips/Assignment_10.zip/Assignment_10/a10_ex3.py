import  numpy as np


def one_hot_encoding(arr: np.ndarray) -> np.ndarray:
    pass
