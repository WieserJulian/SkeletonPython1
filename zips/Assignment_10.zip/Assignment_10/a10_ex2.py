import numpy as np


def elements_wise(arr: np.ndarray, f):
    pass
