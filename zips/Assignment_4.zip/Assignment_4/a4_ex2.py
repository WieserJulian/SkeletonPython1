def clip(*values, min_=0, max_=1) -> list:
    # Todo Your code Here
    pass
