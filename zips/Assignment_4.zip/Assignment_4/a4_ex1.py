def split_list(lst: list, num_sublists: int) -> list:
    # Todo Your code Here
    pass