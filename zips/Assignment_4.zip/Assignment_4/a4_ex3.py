def grade_calculator(
        assignments: list,
        bonus_assignment: int,
        exam: int) -> tuple[bool, int]:
    # Todo Your code Here
    pass
