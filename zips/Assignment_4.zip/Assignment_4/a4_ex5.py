def sort(elements: list, ascending: bool = True):
    # Todo Your code Here
    pass